#pragma once
#include"QUEUE.h"
const int TABLE_SIZE = 15;
class HashTable 
{
private:
    int keys[TABLE_SIZE];
    string values[TABLE_SIZE];
    QUEUE Q;
public:
    HashTable()
    {
        for (int i = 0; i < TABLE_SIZE; ++i) 
        {
            keys[i] = -1;  
        }
    }

    int hashFunction(int key)
    {
        return key % TABLE_SIZE;
    }

    void insert(int key, const string & value)
    {
        int index = hashFunction(key);
        while (keys[index] != -1) 
        {
            index = (index + 1) % TABLE_SIZE;
        }
        keys[index] = key;

        values[index] = value;
    }

    string search(int key) 
    {
        int index = hashFunction(key);

        int start_index = index;
        while (keys[index] != -1) 
        {
            if (keys[index] == key) 
            {
                return values[index];
            }
            index = (index + 1) % TABLE_SIZE;
            if (index == start_index)
            {
                break;
            }
        }
        return "NOT FOUND";
    }

    void remove(int key)
    {
        int index = hashFunction(key);
        int start_index = index;
        while (keys[index] != -1)
        {
            if (keys[index] == key)
            {
                keys[index] = -1;
                values[index] = "";
                return;
            }
            index = (index + 1) % TABLE_SIZE;
            if (index == start_index)
            {
                return;
            }
        }
    }

    void display() 
    {
        for (int i = 0; i < TABLE_SIZE; ++i)
        {
            if (keys[i] != -1)
            {
                cout << "[" << i << "] Key: " << keys[i] << " Value is " << values[i] << endl;
            }
            else 
            {
                cout << "[" << i << "] Empty" << endl;
            }
        }
    }
};
