#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include"Tree.h"

using namespace std;

struct NODE
{
	NODE* next;
	string data;
	NODE(string v) :data(v)
	{
		next = nullptr;
	}
};

class Interface
{
private:
	string  NewName, OldName,OldPassword,NewPassword;
	int age,sign;
public:
	BinaryTree T;
	Interface();
	void InputNewName();   // FOR SIGN IN
	void InputNewPassword();
	void InputOldName();   // FOR LOGIN
	void InputOldPassword();
	void InputAge();
	void InputSign();
	void START();  // INTERFACE
	void Login();
	void SignIn();
	void TodoList();

	string getNewName();// Getters
	string getOldName();
	int getsign();
};

Interface::Interface()
{
	age = 18;
}

string Interface::getNewName()
{
	return NewName;
}

string Interface::getOldName()
{
	return OldName;
}


void Interface::InputNewName()
{
	cout << "\t\t\t\t\t\t~ Create User Name -> ";
	getline(cin,NewName);
	cout << endl;
	if (NewName == "Anas" || NewName == "Sana" || NewName == "Umer")
	{
		cout << "\t\t\t\t\t\t*********** NAME ALREADY EXISTS, TRY AGAIN ! **********" << endl << endl;
		InputNewName();  // RECURSIVE CASE
	}
}

void Interface::InputNewPassword()
{
	cout << "\t\t\t\t\t\t~ Create Password -> ";
	getline(cin,NewPassword);
	cout << endl;
	int len = 0;
	while (NewPassword[len] != '\0')
	{
		len++;
	}
	if (len < 6)
	{
		cout << "\t\t\t\t\t\t************* WEAK PASSWORD, TRY AGAIN ! ************" << endl << endl;
		InputNewPassword();
	}
}

void Interface::InputOldName()
{
	cout << endl << "\t\t\t\t\t\t~ Enter User NAME -> ";
	getline(cin,OldName);
	cout << endl;
	if (OldName != "Anas" && OldName != "Umer" && OldName != "Sana")
	{
		cout << "\t\t\t\t\t\t************ Wrong User Name, TRY AGAIN ! **************" << endl;
		InputOldName(); // RECURSIVE CASE
	}
}

void Interface::InputOldPassword()
{
	cout << "\t\t\t\t\t\t~ Enter Password -> ";
	getline(cin,OldPassword);
	cout << endl;

	if ((OldName == "Anas" && OldPassword != "anas@1122") || (OldName == "Umer" && OldPassword != "umer@3344") || (OldName == "Sana" && OldPassword != "sana@5566"))
	{
		cout << "\t\t\t\t\t\t************ Wrong Password, TRY AGAIN ! ***************" << endl << endl;
		InputOldPassword();  // RECURSIVE CASE
	}
}

void Interface::InputAge()
{
	cout << "\t\t\t\t\t\t~ Enter Age (Should be >= 10 ) -> ";
	cin >> age;
	cout << endl;
	if (age < 10)
	{
		cout << "\t\t\t\t\t\t*********** Age must be >= 10, TRY AGAIN ! *************" << endl << endl;
		InputAge();  // RECURSIVE CASE
	}
}

void Interface::InputSign()
{
	cout << endl << "\t\t\t\t\t\t~ Enter 1 for LOGIN & 2 for SIGN UP -> ";
	cin >> sign;
	cin.ignore();
	cout << endl;

	T.ROOT = T.INSERT(T.ROOT, sign);
	if (sign == 1)
	{
		Login();
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***             <-- SUCCESSFULLY LOGIN  -->          ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl << endl << endl;
	}
	else if (sign == 2)
	{
		SignIn();
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***          <-- SUCCESSFULLY SIGNED IN  -->         ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl << endl << endl;
	}
	else
	{
		cout << "\t\t\t\t\t\t**************** Wrong INPUT, TRY AGAIN ! **************" << endl;
		InputSign();
	}
}

void Interface::START()
{
	cout << " Anas Yousaf\n L1F22BSCS1070\n D-14" << endl << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t***\t\t\t\t\t\t\t\t     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t***                                                  ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                WELLCOME  TO  THE                 ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***        <- TO DO LIST APPLICATION SYSTEM ->       ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                ( TASK ORGANIZOR )                ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                                                  ***     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t\t\t\t\t\t\t\t     ***" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***              <-- SIGN UP OR LOGIN  -->           ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	InputSign();
}

void Interface::Login()
{
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***            <-- LOGIN WITH ID & PASS  -->         ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	InputOldName();
	InputOldPassword();
	system("cls");
}

void Interface::SignIn()
{
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***             <-- PROVIDE YOUR INFO -->            ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl;

	InputNewName();
	InputNewPassword();
	InputAge();
	system("cls");
}

void Interface::TodoList()
{
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t***\t\t\t\t\t\t\t\t     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t***                                                  ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                    MAKE YOUR                     ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***              <-  TO DO LIST  BY ->               ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                   ADDING TASKS                   ***     ***" << endl;
	cout << "\t\t\t\t\t***\t***                                                  ***     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t********************************************************     ***" << endl;
	cout << "\t\t\t\t\t***\t\t\t\t\t\t\t\t     ***" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl;
	cout << "\t\t\t\t\t************************************************************************" << endl << endl;
}