#include"Manipulation.h"
int main()
{
	Interface I;
	Manipulation M;
	I.START();
	I.TodoList();
	M.TakeInput();

	int s = I.T.ROOT->data; string n;
	if (s == 1)
		n = I.getOldName();
	else if (s == 2)
		n = I.getNewName();
	M.TheEnd(s,n);
	return 0;
}