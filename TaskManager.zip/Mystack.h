#pragma once
#include"Interface.h"

class Mystack
{
private:
	NODE* TOP;
public:
	Mystack();
	bool isempty();
	void PUSH(string value);
	void POP();
	void ShowStackTasks();
	void DeleteAllStack();
};

Mystack::Mystack()
{
	TOP = nullptr;
}

bool Mystack::isempty()
{
	if (TOP == nullptr)
		return true;
	else
		return false;
}

void Mystack::PUSH(string value)
{
	NODE* temp = new NODE(value);
	if (isempty())
	{
		TOP = temp;
	}
	else
	{
		temp->next = TOP;
		TOP = temp;
	}
}

void Mystack::POP()
{
	if (isempty())
	{
		return;
	}
	NODE* temp = TOP;
	TOP = TOP->next;
	delete temp;
}

void Mystack::ShowStackTasks()
{
	if (isempty())
	{
		system("cls");
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***          <-- NO TASKS ARE COMPLETED  -->         ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl << endl;
	}
	else
	{
		system("cls");
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***         <-- TASKS THAT ARE COMPLETED  -->        ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl;

		NODE* temp = TOP;
		while (temp != nullptr)
		{
			cout << "\t\t\t\t\t\t~ " << temp->data << endl << endl;
			temp = temp->next;
		}
		cout << endl << endl;
		delete temp;
	}
}

void Mystack::DeleteAllStack()
{
	while (!isempty())
	{
		POP();
	}
}