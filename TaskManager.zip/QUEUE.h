#pragma once
#include"Mystack.h"

int inc;

class QUEUE :public Interface, public Mystack
{
private:
	NODE* FRONT, * REAR;  // store or edit tasks
public:
	int totalTasks, TotalPoints,updatedTasks;
	string inputtask;  // input task
	QUEUE();
	bool isempty();
	void Enqueue(string value);
	void Dequeue();
	void showQueue();
	void setFRONT(NODE*);
	void setREAR(NODE*);
	void setNULL();
	NODE* getFRONT();
	NODE* getREAR();
};

QUEUE::QUEUE()
{
	FRONT = REAR = nullptr;
	totalTasks = TotalPoints = updatedTasks = 0;
}

bool QUEUE::isempty()
{
	if (FRONT == nullptr)
		return true;
	else
		return false;
}

void QUEUE::Enqueue(string value)
{
	NODE* NEWNODE = new NODE(value);
	if (isempty())
	{
		REAR = FRONT = NEWNODE;
	}
	else
	{
		REAR->next = NEWNODE;
		REAR = NEWNODE;
	}
	totalTasks++;
	updatedTasks++;
	TotalPoints += 2;
}

void QUEUE::Dequeue()
{
	NODE* temp = FRONT;
	if (isempty())
	{
		return;
	}
	FRONT = FRONT->next;
	delete temp;
}

void QUEUE::setFRONT(NODE* t)
{
	FRONT = t;
}
void QUEUE::setNULL()
{
	FRONT = REAR = nullptr;
}

void QUEUE::setREAR(NODE* t)
{
	REAR = t;
}

NODE* QUEUE::getFRONT()
{
	return FRONT;
}

NODE* QUEUE::getREAR()
{
	return REAR;
}

void QUEUE::showQueue()
{
	if (isempty())
	{
		system("cls");
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***          <-- NO TASKS ARE ADDED YET -->          ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl;

		return;
	}
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***         <-- YOUR TASKS ARE FOLLOWING -->         ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl;
	NODE* temp = FRONT;
	inc = 0;
	while (temp != nullptr)
	{
		cout << "\t\t\t\t\t\t" << ++inc << ". " << temp->data << endl << endl;
		temp = temp->next;
	}
	cout << endl;
	delete temp;
}
