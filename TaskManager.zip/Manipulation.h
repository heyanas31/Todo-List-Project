#pragma once
#include"QUEUE.h"
class Manipulation :public QUEUE
{
private:
	int exit, options, CompTasks, EarnPoints, tasknumber, once;
	char yesno;
public:
	Mystack St;
	Manipulation();
	void TakeInput();
	void OPTIONS();
	void InputOption();
	void DeleteAllQueue();
	void SetPriority();
	void TheEnd(int,string);
	void getYESNO();
	void ChooseTask();
	void RemoveTask();
};

Manipulation::Manipulation()
{
	exit = -1;
	once = 1;
	yesno = 'A';
	tasknumber = options = CompTasks = EarnPoints = 0;
}

void Manipulation::OPTIONS()
{
	cout << "\t\t\t\t***************************************************************************************" << endl;
	cout << "\t\t\t\t***\t\t                                                                    ***" << endl;
	cout << "\t\t\t\t***\t                  <-- OPTIONS  ARE THE FOLLOWING -->                        ***" << endl;
	cout << "\t\t\t\t***\t\t                                                                    ***" << endl;
	cout << "\t\t\t\t***************************************************************************************" << endl << endl;
	cout << "\t\t\t\t\t\t1) ADD TASKS                    4) SHOW UNCOMPLETED TASKS" << endl << endl;
	cout << "\t\t\t\t\t\t2) SET PRIORITY                 5) SHOW COMPLETED TASKS" << endl << endl;
	cout << "\t\t\t\t\t\t3) REMOVE TASKS                 6) RESET ALL DATA" << endl << endl;
	cout << "\t\t\t\t\t\t                                7) EXIT APP" << endl << endl;
	cout << "\t\t\t\t\t\t~ Enter 1,2,3,4,5,6,7 according to Command;" << endl << endl;
	InputOption();
}

void Manipulation::InputOption()
{
	cout << "\t\t\t\t\t\t~ Select Option -> ";
	cin >> options;
	cin.ignore();
	cout << endl;
	if (options < 0 && options > 6)
	{
		cout << "\t\t\t\t\t\t*************** Wrong Input, TRY AGAIN ! **************" << endl << endl;
		InputOption();  // RECURSIVE CASE
	}
}

void Manipulation::DeleteAllQueue()
{
	while (!QUEUE::isempty())
	{
		Dequeue();
	}
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***         <-- DATA RESET SUCCESSFULLY  -->         ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl << endl;

}

void Manipulation::SetPriority()
{
	if (QUEUE::isempty())
	{
		return;
	}
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***          <-- SET PRIORITY FOR TASKS -->          ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl;
	ChooseTask();
	if (tasknumber == 1)
	{
		cout << "\t\t\t\t\t\t\t\tYOUR TASK IS ALREADY ON TOP" << endl << endl;
		tasknumber = 0;
		return;
	}
	else
	{
		NODE* temp = getFRONT();
		for (int i = 1; i < tasknumber; i++)
		{
			temp = temp->next;
		}

		NODE* previousTemp = getFRONT();
		while (previousTemp->next != temp)
		{
			previousTemp = previousTemp->next;
		}
		NODE* AfterTemp = temp->next;
		if (AfterTemp == nullptr)
		{
			previousTemp->next = nullptr;
			temp->next = getFRONT();
			setFRONT(temp);
			setREAR(previousTemp);
		}
		else
		{
			temp->next = getFRONT();
			previousTemp->next = AfterTemp;
			setFRONT(temp);
		}

	}
}

void Manipulation::ChooseTask()
{
	cout << "\t\t\t\t\t\t~ Enter Task Number -> ";
	cin >> tasknumber;
	cin.ignore();
	cout << endl;
	if (tasknumber > updatedTasks || tasknumber < 1)
	{
		cout << "\t\t\t\t\t\t*************** Wrong Input, TRY AGAIN ! **************" << endl << endl;
		ChooseTask();
	}
}

void Manipulation::getYESNO()
{
	cout << "\t\t\t\t\t\t~ If Completed = Y || If Not Completed N (EXIT = E): ";
	cin >> yesno;
	cin.ignore();
	if (yesno != 'Y' && yesno != 'N' && yesno != 'n' && yesno != 'y' && yesno != 'e' && yesno != 'E')
	{
		cout << "\n\t\t\t\t****************************** Wrong Input, TRY AGAIN ! *******************************" << endl << endl;
		getYESNO();
	}
}

void Manipulation::RemoveTask()
{
	if (QUEUE::isempty())
	{
		return;
	}
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***            <-- REMOVE YOUR TASKS  -->            ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl;

	getYESNO();
	if (yesno == 'E' || yesno == 'e')
	{
		cout << endl;
		yesno = 'A';
		return;
	}
	cout<<endl;
	ChooseTask();
	NODE* temp = getFRONT();
	if (temp->next == nullptr)
	{
		temp = nullptr;
		setFRONT(temp);
		setREAR(temp);
		return;
	}
	else
	{
		if (tasknumber == 1)
		{
			setFRONT(temp->next);
		}
		else
		{
			for (int i = 1; i < tasknumber; i++)
			{
				temp = temp->next;
			}
			NODE* previousTemp = getFRONT();
			while (previousTemp->next != temp)
			{
				previousTemp = previousTemp->next;
			}
			if (temp == getFRONT())
			{
				setFRONT(temp->next);

			}
			else if (temp == getREAR())
			{
				previousTemp->next = nullptr;
				setREAR(previousTemp);
			}
			else
			{
				previousTemp->next = temp->next;
			}
		}
		
	}
	--updatedTasks;

	if (yesno == 'Y' || yesno == 'y')
	{
		St.PUSH(temp->data);
		CompTasks++;
		EarnPoints += 2;
	}
	delete temp;
	yesno = 'A';
	cout << endl;

}
void Manipulation::TakeInput()
{
	if (options == 7)
	{
		return;
	}
	OPTIONS();
	if (options == 1)
	{
		cout << "\t\t\t\t\t\t********************************************************" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t***             <-- INPUT YOUR TASKS  -->            ***" << endl;
		cout << "\t\t\t\t\t\t***                       OR                         ***" << endl;
		cout << "\t\t\t\t\t\t***                 <-- 0 TO EXIT -->                ***" << endl;
		cout << "\t\t\t\t\t\t***                                                  ***" << endl;
		cout << "\t\t\t\t\t\t********************************************************" << endl << endl;

		while (inputtask[0] != '0')
		{
			cout << "\t\t\t\t\t\t~ Write Your Task -> ";
			getline(cin, inputtask);
			cout << endl;
			if (inputtask[0] != '0')
			{
				Enqueue(inputtask);
			}
		}
		inputtask[0] = 'A';
	}
	else if (options == 2)
	{
		SetPriority();
		QUEUE::showQueue();
	}
	else if (options == 3)
	{
		RemoveTask();
		QUEUE::showQueue();
	}
	else if (options == 4)
	{
		system("cls");
		QUEUE::showQueue();
	}
	else if (options == 5)
	{
		St.ShowStackTasks();
	}
	else if (options == 6)
	{
		totalTasks = CompTasks = TotalPoints = EarnPoints = updatedTasks = 0;
		system("cls");
		QUEUE::DeleteAllStack();
		DeleteAllQueue();
	}
	else if (options <= 0 || options >= 8)
	{
		cout << "\t\t\t\t****************************** Wrong Input, TRY AGAIN ! *******************************" << endl << endl;
	}
	cout << endl << endl;
	TakeInput();
	//system("cls");
}

void Manipulation::TheEnd(int s,string name)
{
	system("cls");
	cout << "\t\t\t\t\t\t********************************************************" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t***         <-- YOUR RESULT IS FOLLOWING  -->       ***" << endl;
	cout << "\t\t\t\t\t\t***                                                  ***" << endl;
	cout << "\t\t\t\t\t\t********************************************************" << endl << endl;
	cout << "\t\t\t\t\t\t~ TOTAL TASKS -> " << totalTasks << endl << "\t\t\t\t\t\t~ COMPLETED TASKS -> " << CompTasks << endl << endl;
	cout << "\t\t\t\t\t\t~ TOTAL POINTS -> " << TotalPoints << endl << "\t\t\t\t\t\t~ EARNED POINTS -> " << EarnPoints << endl << endl << endl;
	
	ofstream file2("C:\\Users\\hp\\OneDrive\\Desktop\\ProjectS4\\UserData.csv", ios::app);
	
	//file2 << "NAME,T.TASKS,C.TASKS,T.POINT,E.POINT" << endl;
	
	file2 << name << "," << totalTasks << "," << CompTasks << "," << TotalPoints << "," << EarnPoints << "\n";
	
	BinaryTree T;
	T.ROOT = T.INSERT(T.ROOT, totalTasks);
	T.INSERT(T.ROOT, CompTasks);

	file2.close();

	cout << "\t\t\t\t***************************************************************************************" << endl;
	cout << "\t\t\t\t***\t\t                                                                    ***" << endl;
	cout << "\t\t\t\t***\t                      <-- THANK YOU FOR USING  -->                          ***" << endl;
	cout << "\t\t\t\t***\t\t                                                                    ***" << endl;
	cout << "\t\t\t\t***************************************************************************************" << endl << endl;
}