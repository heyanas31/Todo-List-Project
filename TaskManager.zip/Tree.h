#pragma once
#include<iostream>
using namespace std;
struct TreeNode
{
	TreeNode* left, * right;
	int data;
	TreeNode(int v):data(v),left(nullptr),right(nullptr){}
};
class BinaryTree
{
public:
	TreeNode* ROOT;
	BinaryTree() :ROOT(nullptr)
	{

	}
	
	TreeNode* INSERT(TreeNode* temp, int value)
	{
		if (temp == nullptr)
		{
			temp = new TreeNode(value);
		}
		else
		{
			if (temp->data < value)
			{
				temp->left = INSERT(temp->left, value);
			}
			else
			{
				temp->right = INSERT(temp->right, value);
			}
		}
		return temp;
	}
	void Inorder(TreeNode* temp)
	{
		if (temp != nullptr)
		{
			Inorder(temp->left);
			cout << temp->data << " ";
			Inorder(temp->right);
		}
	}
	void Preorder(TreeNode* temp)
	{
		if (temp != nullptr)
		{
			cout << temp->data << " ";
			Preorder(temp->left);
			Preorder(temp->right);
		}
	}
	void Postorder(TreeNode* temp)
	{
		if (temp != nullptr)
		{
			Postorder(temp->left);
			Postorder(temp->right);
			cout << temp->data << " ";
		}
	}
};